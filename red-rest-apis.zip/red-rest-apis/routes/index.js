var express = require('express');
var app = express();
var fs = require('fs');
var bcrypt = require('bcrypt');
const saltRounds = 10;
var Sequelize = require('sequelize');
var env = "dev";
var config = require('../config.json')[env];
var password = config.password ? config.password : null;
var unique = require('array-unique');
var sequelize = new Sequelize(
    config.database,
    config.user,

    config.password, {
        logging: console.log,
        dialect: 'mysql',
        define: {
            timestamps: false
        },
        sync: true
    }
);
var base64 = require('base-64');

/*fcm setup*/

var FCM = require('fcm-node');
var serverKey = 'AIzaSyBKhE4TofQ8q4OEa-rSxB_mGDTG_ArxT-E';
var fcm = new FCM(serverKey);

/*fcm setup END @24-feb*/

app.set('views', '/var/www/html/red-rest-apis/views');
app.set('view engine', 'ejs');

var mailer = require('express-mailer');

mailer.extend(app, {
    from: 'dummymail0092@gmail.com',
    host: 'smtp.gmail.com', // hostname
    secureConnection: true, // use SSL
    port: 465, // port for secure SMTP
    transportMethod: 'SMTP', // default is SMTP. Accepts anything that nodemailer accepts
    auth: {
        user: 'dummymail0092@gmail.com', // gmail id
        pass: 'kumarSubodh' // gmail password
    }
});
var global_running_url = 'http://18.221.19.112:3002/';
var global_images_url = 'http://18.221.19.112/red-rest-apis/public/images/';
var local_images_url = '/var/www/html/red-rest-apis/public/images/';
//////////////////// MODELS ///////////////////////////

const User = sequelize.define('users', {
    unique_user_id: {
        type: Sequelize.STRING
    },
    occupant_id: {
        type: Sequelize.STRING
    },
    name: {
        type: Sequelize.STRING
    },
    email: {
        type: Sequelize.STRING
    },
    password: {
        type: Sequelize.STRING
    },
    decoded_password: {
        type: Sequelize.STRING
    },
    profile_image: {
        type: Sequelize.STRING
    },
    cover_image: {
        type: Sequelize.STRING
    },
    phone_no: {
        type: Sequelize.STRING
    },
    country_code: {
        type: Sequelize.STRING
    },
    combined_phone_no: {
        type: Sequelize.VIRTUAL,
        get: function() {
            return (this.get('country_code') + this.get('phone_no'));
        }
    },
    gender: {
        type: Sequelize.STRING
    },
    dob: {
        type: Sequelize.DATE
    },
    address: {
        type: Sequelize.STRING
    },
    latitude: {
        type: Sequelize.STRING
    },
    longitude: {
        type: Sequelize.STRING
    },
    about_you: {
        type: Sequelize.STRING
    },
    temp_token: {
        type: Sequelize.STRING
    },
    status: {
        type: Sequelize.ENUM,
        values: ['active', 'inactive']
    },
    created_at: {
        type: Sequelize.DATE
    },
    updated_at: {
        type: Sequelize.DATE
    }
})

const UserContacts = sequelize.define('user_contacts', {
    user_id: {
        type: Sequelize.INTEGER
    },
    receiver_id: {
        type: Sequelize.INTEGER
    },
    blocked_by: {
        type: Sequelize.STRING
    },
    status: {
        type: Sequelize.ENUM,
        values: ['pending', 'accepted', 'blocked']
    },
    created_at: {
        type: Sequelize.DATE
    },
    updated_at: {
        type: Sequelize.DATE
    }
})

const MyPost = sequelize.define('my_posts', {
    user_id: {
        type: Sequelize.INTEGER
    },
    title: {
        type: Sequelize.STRING
    },
    description: {
        type: Sequelize.STRING
    },
    location: {
        type: Sequelize.STRING
    },
    latitude: {
        type: Sequelize.STRING
    },
    longitude: {
        type: Sequelize.STRING
    },
    share: {
        type: Sequelize.ENUM,
        values: ['public', 'private']
    },
    status: {
        type: Sequelize.ENUM,
        values: ['active', 'inactive']
    },
    temp_update: {
        type: Sequelize.STRING
    },
    created_at: {
        type: Sequelize.DATE
    },
    updated_at: {
        type: Sequelize.DATE
    }
})

const PostFiles = sequelize.define('post_files', {
    post_id: {
        type: Sequelize.INTEGER
    },
    attachment_name: {
        type: Sequelize.STRING
    },
    attachment_type: {
        type: Sequelize.ENUM,
        values: ['image', 'video', 'file', 'audio']
    },
    status: {
        type: Sequelize.ENUM,
        values: ['active', 'inactive']
    },
    created_at: {
        type: Sequelize.DATE
    }
})

const FavouritePosts = sequelize.define('favourite_posts', {
    user_id: {
        type: Sequelize.INTEGER
    },
    post_id: {
        type: Sequelize.INTEGER
    },
    status: {
        type: Sequelize.ENUM,
        values: ['active', 'inactive']
    },
    created_at: {
        type: Sequelize.DATE
    }
})

const ChatRoomIds = sequelize.define('chat_room_ids', {
    room_id: {
        type: Sequelize.STRING
    },
    user_id: {
        type: Sequelize.INTEGER
    },
    receiver_id: {
        type: Sequelize.INTEGER
    },
    last_message_id: {
        type: Sequelize.INTEGER
    },
    created_at: {
        type: Sequelize.DATE
    }
})

const Chats = sequelize.define('chats', {
    room_id: {
        type: Sequelize.STRING
    },
    sender_id: {
        type: Sequelize.INTEGER
    },
    receiver_id: {
        type: Sequelize.INTEGER
    },
    message: {
        type: Sequelize.STRING
    },
    attachment: {
        type: Sequelize.STRING
    },
    unique_code: {
        type: Sequelize.STRING
    },
    check_status: {
        type: Sequelize.ENUM,
        values: ['unread', 'read']
    },
    created_at: {
        type: Sequelize.DATE
    }
})

const ViewedPosts = sequelize.define('viewed_posts', {
    user_id: {
        type: Sequelize.INTEGER
    },
    post_id: {
        type: Sequelize.INTEGER
    },
    created_at: {
        type: Sequelize.DATE
    }
})

// const ChatStickersCategories = sequelize.define('chat_stickers_categories',{sticker_category:{type: Sequelize.STRING},
//                                       status :{type: Sequelize.ENUM,values:['active','inactive']},
//                                       created_at:{type: Sequelize.DATE}})

const ChatStickersCategories = sequelize.define('chat_stickers_categories', {
    sticker_category: {
        type: Sequelize.STRING
    },
    status: {
        type: Sequelize.ENUM,
        values: ['active', 'inactive']
    },
    created_at: {
        type: Sequelize.DATE
    }
})

const ChatStickers = sequelize.define('chat_stickers', {
    sticker_category_id: {
        type: Sequelize.INTEGER
    },
    sticker_image: {
        type: Sequelize.STRING
    },
    status: {
        type: Sequelize.ENUM,
        values: ['active', 'inactive']
    },
    created_at: {
        type: Sequelize.DATE
    }
})

const GcmDevices = sequelize.define('gcm_devices', {
    user_id: {
        type: Sequelize.INTEGER
    },
    device_type: {
        type: Sequelize.ENUM,
        values: ['android', 'ios']
    },
    device_id: {
        type: Sequelize.STRING
    },
    device_token: {
        type: Sequelize.STRING
    },
    occupant_id: {
        type: Sequelize.STRING
    },
    ios_voice_token: {
        type: Sequelize.STRING
    }
})

const favcontentfromchat = sequelize.define('favourite_content_from_chat', { //mohit

    user_id: {
        type: Sequelize.INTEGER
    },
    text: {
        type: Sequelize.STRING
    },
    occupant_id: {
        type: Sequelize.STRING
    },
    unique_check: {
        type: Sequelize.STRING
    },
    attachment: {
        type: Sequelize.STRING
    },
    attachment_type: {
        type: Sequelize.STRING
    },
    thumbnail: {
        type: Sequelize.STRING
    },
    lat: {
        type: Sequelize.STRING
    },
    long: {
        type: Sequelize.STRING
    },
    address: {
        type: Sequelize.STRING
    },
    created_at: {
        type: Sequelize.DATE
    },


}, {
    tableName: 'favourite_content_from_chat'
});

const QuickbloxChatUsers = sequelize.define('quickblox_chat_users', {
    user_id: {
        type: Sequelize.INTEGER
    },
    receiver_user_id: {
        type: Sequelize.INTEGER
    },
    occupant_id: {
        type: Sequelize.STRING
    },
    hide_status: {
        type: Sequelize.ENUM,
        values: ['1', '0']
    }
})

const UsersAppPasscode = sequelize.define('users_app_passcodes', {
    user_id: {
        type: Sequelize.INTEGER
    },
    passcode: {
        type: Sequelize.INTEGER
    },
    created_at: {
        type: Sequelize.DATE
    },
    updated_at: {
        type: Sequelize.DATE
    }
});

const VolteContentFromChat = sequelize.define('volte_content_from_chats', { //subodh kumar @ 23-march-2018
    user_id: {
        type: Sequelize.INTEGER
    },
    text: {
        type: Sequelize.STRING
    },
    occupant_id: {
        type: Sequelize.STRING
    },
    unique_check: {
        type: Sequelize.STRING
    },
    attachment: {
        type: Sequelize.STRING
    },
    attachment_type: {
        type: Sequelize.STRING
    },
    thumbnail: {
        type: Sequelize.STRING
    },
    lat: {
        type: Sequelize.STRING
    },
    long: {
        type: Sequelize.STRING
    },
    address: {
        type: Sequelize.STRING
    },
    created_at: {
        type: Sequelize.DATE
    }
});

const UserSettings = sequelize.define('user_settings', {
    user_id: {
        type: Sequelize.INTEGER
    },
    send_message_notification: {
        type: Sequelize.ENUM,
        values: ['yes', 'no']
    }
})
//////////////////MODELS END///////////////////////////////

//////////////////// Associations ////////////////////

MyPost.hasMany(PostFiles, {
    foreignKey: 'post_id',
    as: 'post_attachments_in_post'
})

UserContacts.belongsTo(User, {
    foreignKey: 'receiver_id',
    as: 'receiver_user_in_usercontacts'
})

UserContacts.belongsTo(User, {
    foreignKey: 'user_id',
    as: 'sender_user_in_usercontacts'
})

ChatRoomIds.hasMany(Chats, {
    foreignKey: 'room_id',
    sourceKey: 'room_id',
    as: 'chat_in_chatrooms'
})

ChatRoomIds.hasOne(Chats, {
    foreignKey: 'room_id',
    sourceKey: 'room_id',
    as: 'chats_under_chatrooms'
})

ChatRoomIds.belongsTo(User, {
    foreignKey: 'receiver_id',
    as: 'receiver_user_in_chatrooms'
})

ChatRoomIds.belongsTo(User, {
    foreignKey: 'user_id',
    as: 'sender_user_in_chatrooms'
})

ChatRoomIds.belongsTo(Chats, {
    foreignKey: 'last_message_id',
    as: 'chatroom_in_chats'
})


MyPost.belongsTo(User, {
    foreignKey: 'user_id',
    as: 'user_in_mypost'
})

MyPost.hasOne(FavouritePosts, {
    foreignKey: 'post_id',
    as: 'favourite_posts_in_mypost'
})

FavouritePosts.belongsTo(MyPost, {
    foreignKey: 'post_id',
    as: 'mypost_in_favourite_posts'
})

ChatStickersCategories.hasMany(ChatStickers, {
    foreignKey: 'sticker_category_id',
    as: 'chat_stickers_in_category'
})

favcontentfromchat.belongsTo(User, {
    foreignKey: 'occupant_id',
    targetKey: 'occupant_id',
    as: 'ChatUsersDetails'
})
/*subodh kumar @ 23-march-2018 'voltecontent table association with user'*/
VolteContentFromChat.belongsTo(User, {
    foreignKey: 'occupant_id',
    targetKey: 'occupant_id',
    as: 'VolteChatUsersDetails'
})

QuickbloxChatUsers.belongsTo(User, {
    foreignKey: 'receiver_user_id',
    as: 'receiver_user_in_quickblox'
})

User.hasOne(UsersAppPasscode, {
    foreignKey: 'user_id',
    as: 'app_passcode_in_user'
})

GcmDevices.belongsTo(UserSettings, {
    foreignKey: 'user_id',
    targetKey: 'user_id',
    as: 'user_settings_in_gcm_devices'
})
////////////////// End Association //////////////////

////// SEND NOTIFICATION ANDROID/ ///////

function sendNotificationAndroid(to, title, body, notification_type, data_id, data_array, callback) {
    //var x=[];
    var message = { //this may vary according to the message type (single recipient, multicast, topic, et cetera) 
        to: to,
        //collapse_key: 'your_collapse_key',

        notification: {

        },

        data: { //you can send only notification or only data(or include both) 
            title: title,
            message: body,
            notification_type: notification_type,
            data_id: data_id,
            data_array: data_array
        },
        time_to_live: 604800
    };

    var v = fcm.send(message, function(err, response) {
        if (err) {
            console.log('<FCM ERROR:->', err);
            console.log("Something has gone wrong!");
        } else {
            console.log('<FCM RESPONSE:->', response);
            callback(response);
            //x=response;
        }
    });
    console.log(v);
}

////// SEND NOTIFICATION ANDROID END/ ///////

////// SEND NOTIFICATION IOS/ ///////
function sendNotificationIos(to, title, body, notification_type, data_id, data_array, callback) {
    const apn = require("apn");
    let tokens = [to];
    let service = new apn.Provider({
        cert: "/var/www/html/red-rest-apis/public/red.pem",
        key: "/var/www/html/red-rest-apis/public/redKey.pem",
    });

    let note = new apn.Notification({
        alert:{
            title: title,
            body : body,
            // notification_type: notification_type,
            // data_id: data_id
        }	
    });

    // The topic is usually the bundle identifier of your application
    note.payload = {
        //title: title,
        notification_type: notification_type,
        data_id: data_id,
        data_array: data_array
    }
    //note.body = body;
    note.topic = "Promatics.RED";
    //note.title = title;
    note.sound = 'default';
    //note.peopleIdentifiers="hh";

    console.log('Sending: ${note.compile()} to ${tokens}');
    service.send(note, tokens).then(result => {
        console.log("IN IOS SEND NOTIFICATION")
        console.log("sent:", result.sent.length);
        console.log("failed:", result.failed.length);
        console.log(result.sent);
        console.log(result.failed);
    });
    service.shutdown();
}

function sendNotificationIosVoice(to, title, body, notification_type, data_id, data_array, callback) {
    const apn = require("apn");
    let tokens = [to];
    let service = new apn.Provider({
        cert: "/var/www/html/red-rest-apis/public/redVOIPCert.pem",
        key: "/var/www/html/red-rest-apis/public/redVOIPKey.pem",
    });

    let note = new apn.Notification({   
        alert : body
    });

    // The topic is usually the bundle identifier of your application
    note.payload = {
        title: title,
        notification_type: notification_type,
        data_id: data_id,
        data_array: data_array
    }
    //note.body = body;
    //note.topic = "Promatics.RED";
    note.title = title;
    note.sound = 'default';
    //note.peopleIdentifiers="hh";

    console.log('Sending: ${note.compile()} to ${tokens}');
    service.send(note, tokens).then(result => {
        console.log("IN IOS SEND NOTIFICATION")
        console.log("sent:", result.sent.length);
        console.log("failed:", result.failed.length);
        console.log(result.sent);
        console.log(result.failed);
    });
    service.shutdown();
}

////// SEND NOTIFICATION IOS END/ ///////

exports.home = function(req, res) {
    console.log('In Red-rest-apis');
    res.write('<h1>You are on home page of <span style=" color:red;">Red project</span></h1>');
    res.end();
}

exports.notFound = function(req, res) {
    res.write('<h1>404</h1>');
    res.write('Sorry the page you are requesting not found');
}

exports.sign_up = function(req, res) {
    var name = req.body.name,
        email = req.body.email.toLowerCase(),
        password = req.body.password,
        phone_no = req.body.phone_no,
        country_code = req.body.country_code;

    if (name != "" && name != null && email != "" && email != null && password != "" && password != null && phone_no != "" && phone_no != null && country_code != "" && country_code != null) {
        User.findOne({
            where: {
                email: email
            }
        }).then(function(resl) {
            if (resl == null) {
                if (password.length >= 6) {
                    bcrypt.hash(password, saltRounds, function(err, hash) {
                        User.create({
                            name: name,
                            email: email,
                            password: hash,
                            decoded_password: password,
                            phone_no: phone_no,
                            country_code: country_code
                        }).then(function(result) {
                            result.update({
                                unique_user_id: 'R' + Math.random().toString(36).slice(-3) + result.id + (Math.random().toString(36).slice(-2)).toUpperCase()
                            })
                            UserSettings.create({user_id : result.id});
                            res.end(JSON.stringify({
                                response: 1,
                                message: "signed up successfully"
                            }));
                        }, function(error) {
                            res.end(JSON.stringify({
                                response: 0,
                                message: "some error occured"
                            }));
                        })
                    });
                } else {
                    res.end(JSON.stringify({
                        response: 0,
                        message: "Password is too short"
                    }));
                }
            } else {
                res.end(JSON.stringify({
                    response: 0,
                    message: "Email already exist"
                }));
            }
        }, function(err) {
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "some data is missing"
        }));
    }
}

exports.login = function(req, res) {
    var email = req.body.email.toLowerCase(),
        password = req.body.password,
        occupant_id = req.body.occupant_id;

    if (email != "" && email != null && password != "" && password != null  && occupant_id != "" && occupant_id != null) {
        User.findOne({
            where: {
                email: email
            },include:[{
                model:UsersAppPasscode,
                as:'app_passcode_in_user'
            }]
        }).then(function(result) {
            if (result != null) {
                bcrypt.compare(password, result.password, function(err, ress) {
                    if (ress) {
                        result.update({occupant_id:occupant_id});
                        delete result.decoded_password;
                        res.end(JSON.stringify({
                            response: 1,
                            message: "Logged in successfully",
                            result: result
                        }));
                    } else {
                        res.end(JSON.stringify({
                            response: 0,
                            message: "Password not matched"
                        }));
                    }
                });
            } else {
                res.end(JSON.stringify({
                    response: 0,
                    message: "Email does not exist"
                }));
            }
        }, function(error) {
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "some data is missing"
        }));
    }
}

exports.change_password = function(req, res) {
    // res.json('hdbc');
    var user_id = req.body.user_id,
        old_password = req.body.old_password,
        new_password = req.body.new_password;

    if (user_id != "" && user_id != null && old_password != "" && old_password != null && new_password != "" && new_password != null) {
        User.findOne({
            where: {
                id: user_id
            }
        }).then(function(result) {
            if (result != null) {
                if (new_password.length >= 6) {
                    bcrypt.compare(old_password, result.password, function(err, ress) {
                        if (ress) {
                            bcrypt.hash(new_password, saltRounds, function(err, hash) {
                                result.update({
                                    password: hash,
                                    decoded_password: new_password
                                }).then(function(resul) {
                                    res.end(JSON.stringify({
                                        response: 1,
                                        message: "Password changed"
                                    }));
                                }, function(error) {
                                    res.end(JSON.stringify({
                                        response: 0,
                                        message: "some error occured"
                                    }));
                                })
                            });
                            //res.end(JSON.stringify({response:1, message:"signed up successfully", result:result}));
                        } else {
                            res.end(JSON.stringify({
                                response: 0,
                                message: "Password not matched"
                            }));
                        }
                    });
                } else {
                    res.end(JSON.stringify({
                        response: 0,
                        message: "Password is too short"
                    }));
                }
            } else {
                res.end(JSON.stringify({
                    response: 0,
                    message: "user does not exist"
                }));
            }
        }, function(error) {
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "some data is missing"
        }));
    }
}

exports.forgot_password = function(req, res) {
    var email = req.body.email.toLowerCase();
    if (email != "" && email != null) {
        User.findOne({
            where: {
                email: email
            }
        }).then(function(result) {
            var token = Math.random().toString(36).substring(7);
            if (result != null) {
                result.update({
                    temp_token: token
                });
                var mailOptions = {
                    to: result.email,
                    subject: 'Red (Link to reset password)',
                    user: {
                        user_name: result.name,
                        url: global_running_url+'resetPassword/' + base64.encode(result.id) + '/' + token,
                        path: global_images_url
                    }
                }
                send_email('red_reset_pass', mailOptions, function() {
                    res.end(JSON.stringify({
                        response: 1,
                        message: "We have sent you an email to reset your password"
                    }));
                });
            } else {
                res.end(JSON.stringify({
                    response: 0,
                    message: "user email not found"
                }));
            }
        }, function(error) {
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        })
    }
}

exports.reset_password = function(req, res) {
    var user_id = req.params.user_id,
        token = req.params.token;
    if (user_id != "" && user_id != null && token != "" && token != null) {
        user_id = base64.decode(user_id);
        //remember_token=base64.decode(remember_token);
        console.log(token);
        User.findOne({
            where: {
                id: user_id
            }
        }).then(function(result) {
            if (result != null) {
                if (result.temp_token == token) {
                    res.render('reset-password', {
                        user_id: user_id,
                        path: global_images_url
                    });
                } else {
                    //res.render('token-expire');
                    res.render('token-expire');
                }
            } else {
                res.render('error-password', {
                    message: 'Link is expired.'
                });
            }
        }, function(error) {
            res.render('error-password', {
                message: 'Something went wrong, Please go back and try again.'
            });
        })
    } else {
        res.render('token-expire');
    }
}

exports.submit_reset_password = function(req, res) {
    var user_id = req.body.user_id,
        password = req.body.newPassword;

    if (user_id != "" && user_id != null && password != "" && password != null) {
        User.findOne({
            where: {
                id: user_id
            }
        }).then(function(result) {
            if (result != null) {
                bcrypt.hash(password, saltRounds, function(err, hash) {
                    result.update({
                        password: hash,
                        decoded_password: password,
                        temp_token: ""
                    }).then(function(resul) {
                        res.render('success-password', {
                            message: 'Congratulations !! Password changed successfully'
                        });
                    }, function(error) {
                        res.render('token-expire');
                    })
                });
            } else {
                res.render('token-expire');
            }
        })
    } else {
        res.render('token-expire');
    }
}

exports.submit_reset_password_from_app = function(req, res) {
    var user_id = req.body.user_id,
        token = req.body.token,
        password = req.body.password;

    if (user_id != "" && user_id != null && password != "" && password != null && token != "" && token != null) {
        user_id = base64.decode(user_id);
        User.findOne({
            where: {
                id: user_id
            }
        }).then(function(result) {
            if (result != null) {
                if (token == result.temp_token) {
                    bcrypt.hash(password, saltRounds, function(err, hash) {
                        result.update({
                            password: hash,
                            decoded_password: password,
                            temp_token: ""
                        }).then(function(resul) {
                            res.end(JSON.stringify({
                                response: 1,
                                message: "Password updated successfully"
                            }));
                        }, function(error) {
                            res.end(JSON.stringify({
                                response: 0,
                                message: "some error occured"
                            }));
                        })
                    });
                } else {
                    res.end(JSON.stringify({
                        response: 0,
                        message: "token miss match"
                    }));
                }
            } else {
                res.end(JSON.stringify({
                    response: 0,
                    message: "User not found"
                }));
            }
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));
    }
}

exports.user_edit_profile = function(req, res) {
    var user_id = req.body.user_id,
        name = req.body.name,
        phone_no = req.body.phone_no,
        country_code = req.body.country_code,
        gender = req.body.gender,
        dob = req.body.dob,
        address = req.body.address,
        latitude = req.body.latitude,
        longitude = req.body.longitude,
        update_data = {},
        date = Date.now() + '_',
        about_you = req.body.about_you;

    if (user_id != "" && user_id != null) {
        if (name != null) {
            update_data.name = name;
        }
        if (phone_no != null) {
            update_data.phone_no = phone_no;
        }
        if (about_you != null) {
            update_data.about_you = about_you;
        }
        if (country_code != null) {
            update_data.country_code = country_code;
        }
        if (gender != null) {
            if (gender == 1) {
                update_data.gender = "male";
            } else if (gender == 2) {
                update_data.gender = "female";
            }
        }
        if (dob != null) {
            update_data.dob = dob;
        }
        if (address != null && latitude != null && longitude != null) {
            update_data.address = address;
            update_data.latitude = latitude;
            update_data.longitude = longitude;
        }
        if (req.files) {
            if (req.files.profile_image) {
                let profile_img = req.files.profile_image;
                profile_img.mv(local_images_url + 'profile_imgs/' + date + profile_img.name, function(err) {
                    if (err) {
                        console.log(err);
                        res.send({
                            response: 0,
                            message: 'some problem to upload profile image'
                        });
                    }
                    //res.send({response:'1',message:'Id proof uploaded!',result:id_proof.name});
                });
                update_data.profile_image = date + profile_img.name;
            }

            if (req.files.cover_image) {
                let cover_img = req.files.cover_image;
                cover_img.mv(local_images_url + 'cover_imgs/' + date + cover_img.name, function(err) {
                    if (err) {
                        console.log(err);
                        res.send({
                            response: 0,
                            message: 'some problem to upload profile image'
                        });
                    }
                    //res.send({response:'1',message:'Id proof uploaded!',result:id_proof.name});
                });
                update_data.cover_image = date + cover_img.name;
            }
        }

        User.update(update_data, {
            where: {
                id: user_id
            }
        }).then(function(result) {
            //res.json(result);
            if (result == 1) {
                User.findOne({
                    where: {
                        id: user_id
                    }
                }).then(function(resul) {
                    res.end(JSON.stringify({
                        response: 1,
                        message: "user profile updated",
                        result: resul
                    }));
                }, function(err) {
                    console.log('1 ', err);
                    res.end(JSON.stringify({
                        response: 0,
                        message: "some error occured"
                    }));
                })
            } else {
                res.end(JSON.stringify({
                    response: 0,
                    message: "profile not updated"
                }));
            }
        }, function(error) {
            console.log('1 ', error);
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));
    }

}

exports.user_contact_list_create = function(req, res) {
    var contacts = req.body.contacts,
        user_id = req.body.user_id;

    if (contacts != null && contacts.length > 0 && user_id != "" && user_id != null) {
        if (!Array.isArray(contacts)) {
            contacts = [req.body.contacts];
        }
        var incc = 0,
            filter_contacts = new Array();
        for (i = 0; i < contacts.length; i++) {
            //for(j=0;j<contacts.i.number.length;j++){
            if (contacts[i] != "" && contacts[i] != null) {
                filter_contacts[incc] = contacts[i].replace(/\D/g, '');
                incc++;
            }
        }
        //res.json(filter_contacts);
        User.findAll({
            where: Sequelize.or(Sequelize.where(
                Sequelize.fn("CONCAT",
                    Sequelize.col("country_code"),
                    Sequelize.col("phone_no")
                ),
                Sequelize.or(filter_contacts)
            ), {
                phone_no: filter_contacts
            })
        }).then(function(result) {
            if (result.length > 0) {
                var ids = [];
                for (i = 0; i < result.length; i++) {
                    if (result[i].id != "") {
                        ids.push(result[i].id);
                    }
                }
                ids = unique(ids);
                for (i = 0; i < ids.length; i++) {
                    if (ids[i] != "" && ids[i] != null) {
                        if (user_id != ids[i]) {
                            UserContacts.findOrCreate({
                                where: [{
                                    $or: [{
                                        user_id: user_id,
                                        receiver_id: ids[i]
                                    }, {
                                        user_id: ids[i],
                                        receiver_id: user_id
                                    }]
                                }],
                                defaults: {
                                    user_id: user_id,
                                    receiver_id: ids[i],
                                    status: 'accepted'
                                }
                            })
                        }
                    }
                    if (i == ids.length - 1) {
                        res.end(JSON.stringify({
                            response: 1,
                            message: "contact list created"
                        }));
                    }
                }
            } else {
                res.end(JSON.stringify({
                    response: 0,
                    message: "no contacts found"
                }));
            }
            //res.json(result);
        }, function(error) {
            console.log(error);
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));
    }
}

exports.user_add_post = function(req, res) {
    var user_id = req.body.user_id,
        title = req.body.title,
        description = req.body.description,
        location = req.body.location,
        latitude = req.body.latitude,
        longitude = req.body.longitude,
        share = req.body.share,
        post_data = {},
        date = Date.now();

    if (user_id != "" && user_id != null && share != "" && share != null) {
        if (!req.files) {
            if (title == null || title == "") {
                res.end(JSON.stringify({
                    response: 0,
                    message: "Data is empty"
                }));
            }
        }
        if (share == 1) {
            post_data.share = 'public';
        } else {
            if (share == 2) {
                post_data.share = 'private';
            } else {
                res.end(JSON.stringify({
                    response: 0,
                    message: "wrong share type"
                }));
            }
        }
        post_data.user_id = user_id;

        if (title != null && title != "") {
            post_data.title = title;
        }

        if (description != null && description != "") {
            post_data.description = description;
        }

        if (location != null && location != "" && latitude != null && latitude != "" && longitude != null && longitude != "") {
            post_data.location = location;
            post_data.latitude = latitude;
            post_data.longitude = longitude;
        }

        MyPost.create(post_data).then(function(result) {
            if (result != null) {
                if (req.files) {
                    if (req.files.images) {
                        if (!Array.isArray(req.files.images)) {
                            req.files.images = [req.files.images];
                        }

                        if (Array.isArray(req.files.images)) {
                            let images = req.files.images;
                            for (i = 0; i < images.length; i++) {
                                //res.json(obj);
                                let obj = images[i];
                                obj.mv(local_images_url + 'post_attachments/' + date + '_' + obj.name, function(err) {
                                    if (err) {
                                        console.log(err);
                                        res.send({
                                            response: 0,
                                            message: 'some problem to upload images'
                                        });
                                    } else {
                                        PostFiles.create({
                                            post_id: result.id,
                                            attachment_name: date + '_' + obj.name,
                                            attachment_type: 'image'
                                        });
                                    }
                                });
                            }
                        }
                    }

                    if (req.files.audios) {
                        if (!Array.isArray(req.files.audios)) {
                            req.files.audios = [req.files.audios];
                        }

                        if (Array.isArray(req.files.audios)) {
                            let audios = req.files.audios;
                            for (i = 0; i < audios.length; i++) {
                                //res.json(obj);
                                let obj = audios[i];
                                obj.mv(local_images_url + 'post_attachments/' + date + '_' + obj.name, function(err) {
                                    if (err) {
                                        console.log(err);
                                        res.send({
                                            response: 0,
                                            message: 'some problem to upload images'
                                        });
                                    } else {
                                        PostFiles.create({
                                            post_id: result.id,
                                            attachment_name: date + '_' + obj.name,
                                            attachment_type: 'audio'
                                        });
                                    }
                                });
                            }
                        }
                    }

                    if (req.files.files) {
                        if (!Array.isArray(req.files.files)) {
                            req.files.files = [req.files.files];
                        }

                        if (Array.isArray(req.files.files)) {
                            let files = req.files.files;
                            for (i = 0; i < files.length; i++) {
                                //res.json(obj);
                                let obj = files[i];
                                obj.mv(local_images_url + 'post_attachments/' + date + '_' + obj.name, function(err) {
                                    if (err) {
                                        console.log(err);
                                        res.send({
                                            response: 0,
                                            message: 'some problem to upload images'
                                        });
                                    } else {
                                        PostFiles.create({
                                            post_id: result.id,
                                            attachment_name: date + '_' + obj.name,
                                            attachment_type: 'file'
                                        });
                                    }
                                });
                            }
                        }
                    }

                    if (req.files.videos) {
                        if (!Array.isArray(req.files.videos)) {
                            req.files.videos = [req.files.videos];
                        }

                        if (Array.isArray(req.files.videos)) {
                            let videos = req.files.videos;
                            for (i = 0; i < videos.length; i++) {
                                //res.json(obj);
                                let obj = videos[i];
                                obj.mv(local_images_url + 'post_attachments/' + date + '_' + obj.name, function(err) {
                                    if (err) {
                                        console.log(err);
                                        res.send({
                                            response: 0,
                                            message: 'some problem to upload images'
                                        });
                                    } else {
                                        PostFiles.create({
                                            post_id: result.id,
                                            attachment_name: date + '_' + obj.name,
                                            attachment_type: 'video'
                                        });
                                    }
                                });
                            }
                        }
                    }
                }
                res.end(JSON.stringify({
                    response: 1,
                    message: "post created"
                }));
            } else {
                res.end(JSON.stringify({
                    response: 0,
                    message: "post not created"
                }));
            }
        }, function(error) {
            console.log(error);
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        })

    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));
    }
}

exports.get_my_posts = function(req, res) {
    var user_id = req.body.user_id;

    if (user_id != null && user_id != "") {
        MyPost.findAll({
            where: {
                user_id: user_id
            },
            include: [{
                model: PostFiles,
                as: 'post_attachments_in_post'
            }],
            order: [
                ['id', 'desc']
            ]
        }).then(function(result) {
            if (result.length > 0) {
                res.end(JSON.stringify({
                    response: 1,
                    message: "your posts found",
                    result: result
                }));
            } else {
                res.end(JSON.stringify({
                    response: 0,
                    message: "no post found"
                }));
            }
        }, function(error) {
            console.log(error);
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));
    }
}

exports.delete_post_attachment = function(req, res) {
    var post_id = req.body.post_id,
        post_attachments_id = req.body.post_attachments_id;
    // console.log(req.body);
    if (post_id != "" && post_id != null && post_attachments_id != "" && post_attachments_id != null) {
        PostFiles.findOne({
            where: [{
                post_id: post_id
            }, {
                id: post_attachments_id
            }]
        }).then(function(result) {
            if (result != null) {
                fs.unlink(local_images_url + 'post_attachments/' + result.attachment_name, function(error) {

                });
                result.destroy().then(function(resul) {
                    MyPost.findOne({
                        where: {
                            id: post_id
                        }
                    }).then(function(resll) {
                        if (resll.temp_update == 'none') {
                            resll.update({
                                temp_update: 'nones'
                            });
                        } else {
                            resll.update({
                                temp_update: 'none'
                            });
                        }
                    }, function(errr) {
                        res.end(JSON.stringify({
                            response: 0,
                            message: "some error occured"
                        }));
                    });
                    res.end(JSON.stringify({
                        response: 1,
                        message: "attachment deleted",
                        result: resul
                    }));
                }, function(err) {
                    console.log(err);
                    res.end(JSON.stringify({
                        response: 0,
                        message: "some error occured"
                    }));
                });
            } else {
                res.end(JSON.stringify({
                    response: 0,
                    message: "can't delete attachment"
                }));
            }
        }, function(error) {
            console.log(error);
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));
    }
}

exports.edit_my_post = function(req, res) {
    var user_id = req.body.user_id,
        post_id = req.body.post_id,
        title = req.body.title,
        description = req.body.description,
        location = req.body.location,
        latitude = req.body.latitude,
        longitude = req.body.longitude,
        share = req.body.share,
        post_data = {},
        date = Date.now();

    if (user_id != "" && user_id != null && post_id != "" && post_id != null) {

        if (share != null) {
            if (share == 1) {
                post_data.share = 'public';
            } else {
                if (share == 2) {
                    post_data.share = 'private';
                }
            }
        }

        if (title != null) {
            post_data.title = title;
        }

        if (description != null) {
            post_data.description = description;
        }

        if (location != null && latitude != null && longitude != null) {
            post_data.location = location;
            post_data.latitude = latitude;
            post_data.longitude = longitude;
        }

        MyPost.findOne({
            where: [{
                id: post_id
            }, {
                user_id: user_id
            }]
        }).then(function(resll) {
            if (resll != null) {
                if (resll.temp_update == 'none') {
                    post_data.temp_update = 'nones';
                } else {
                    post_data.temp_update = 'none';
                }
                resll.update(post_data).then(function(result) {
                    if (result != null) {
                        if (req.files) {
                            if (req.files.images) {
                                if (!Array.isArray(req.files.images)) {
                                    req.files.images = [req.files.images];
                                }

                                if (Array.isArray(req.files.images)) {
                                    let images = req.files.images;
                                    for (i = 0; i < images.length; i++) {
                                        //res.json(obj);
                                        let obj = images[i];
                                        obj.mv(local_images_url + 'post_attachments/' + date + '_' + obj.name, function(err) {
                                            if (err) {
                                                console.log(err);
                                                res.send({
                                                    response: 0,
                                                    message: 'some problem to upload images'
                                                });
                                            } else {
                                                PostFiles.create({
                                                    post_id: post_id,
                                                    attachment_name: date + '_' + obj.name,
                                                    attachment_type: 'image'
                                                });
                                            }
                                        });
                                    }
                                }
                            }

                            if (req.files.audios) {
                                if (!Array.isArray(req.files.audios)) {
                                    req.files.audios = [req.files.audios];
                                }

                                if (Array.isArray(req.files.audios)) {
                                    let audios = req.files.audios;
                                    for (i = 0; i < audios.length; i++) {
                                        //res.json(obj);
                                        let obj = audios[i];
                                        obj.mv(local_images_url + 'post_attachments/' + date + '_' + obj.name, function(err) {
                                            if (err) {
                                                console.log(err);
                                                res.send({
                                                    response: 0,
                                                    message: 'some problem to upload images'
                                                });
                                            } else {
                                                PostFiles.create({
                                                    post_id: post_id,
                                                    attachment_name: date + '_' + obj.name,
                                                    attachment_type: 'audio'
                                                });
                                            }
                                        });
                                    }
                                }
                            }

                            if (req.files.files) {
                                if (!Array.isArray(req.files.files)) {
                                    req.files.files = [req.files.files];
                                }

                                if (Array.isArray(req.files.files)) {
                                    let files = req.files.files;
                                    for (i = 0; i < files.length; i++) {
                                        //res.json(obj);
                                        let obj = files[i];
                                        obj.mv(local_images_url + 'post_attachments/' + date + '_' + obj.name, function(err) {
                                            if (err) {
                                                console.log(err);
                                                res.send({
                                                    response: 0,
                                                    message: 'some problem to upload images'
                                                });
                                            } else {
                                                PostFiles.create({
                                                    post_id: post_id,
                                                    attachment_name: date + '_' + obj.name,
                                                    attachment_type: 'file'
                                                });
                                            }
                                        });
                                    }
                                }
                            }

                            if (req.files.videos) {
                                if (!Array.isArray(req.files.videos)) {
                                    req.files.videos = [req.files.videos];
                                }

                                if (Array.isArray(req.files.videos)) {
                                    let videos = req.files.videos;
                                    for (i = 0; i < videos.length; i++) {
                                        //res.json(obj);
                                        let obj = videos[i];
                                        obj.mv(local_images_url + 'post_attachments/' + date + '_' + obj.name, function(err) {
                                            if (err) {
                                                console.log(err);
                                                res.send({
                                                    response: 0,
                                                    message: 'some problem to upload images'
                                                });
                                            } else {
                                                PostFiles.create({
                                                    post_id: post_id,
                                                    attachment_name: date + '_' + obj.name,
                                                    attachment_type: 'video'
                                                });
                                            }
                                        });
                                    }
                                }
                            }
                        }
                        res.end(JSON.stringify({
                            response: 1,
                            message: "post updated"
                        }));
                    } else {
                        res.end(JSON.stringify({
                            response: 0,
                            message: "post not updated"
                        }));
                    }
                }, function(error) {
                    console.log(error);
                    res.end(JSON.stringify({
                        response: 0,
                        message: "some error occured"
                    }));
                })
            } else {
                res.end(JSON.stringify({
                    response: 0,
                    message: "Post id is incorrect"
                }));
            }
        }, function(errr) {
            console.log(errr);
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        })

    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));
    }
}

exports.delete_my_post = function(req, res) {
    var user_id = req.body.user_id,
        post_id = req.body.post_id;

    if (user_id != "" && user_id != null && post_id != "" && post_id != null) {
        MyPost.findOne({
            where: [{
                user_id: user_id
            }, {
                id: post_id
            }]
        }).then(function(result) {
            if (result != null) {
                MyPost.destroy({
                    where: [{
                        user_id: user_id
                    }, {
                        id: post_id
                    }]
                }).then(function(resl) {
                    if (resl == 1) {
                        PostFiles.findAll({
                            where: {
                                post_id: post_id
                            }
                        }).then(function(resll) {
                            if (resll.length > 0) {
                                for (i = 0; i < resll.length; i++) {
                                    fs.unlink(local_images_url + 'post_attachments/' + resll[i].attachment_name, function(error) {

                                    });
                                }
                                PostFiles.destroy({
                                    where: {
                                        post_id: post_id
                                    }
                                });
                            }
                        })
                        res.send(JSON.stringify({
                            response: 1,
                            message: 'Post Deleted'
                        }))
                    } else {
                        res.end(JSON.stringify({
                            response: 0,
                            message: "can't delete post"
                        }));
                    }
                })
            } else {
                res.end(JSON.stringify({
                    response: 0,
                    message: "Post id is incorrect"
                }));
            }
        }, function(error) {
            console.log(error);
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));
    }
}

exports.add_post_favourite = function(req, res) {
    var user_id = req.body.user_id,
        post_id = req.body.post_id;

    if (user_id != "" && user_id != null && post_id != "" && post_id != null) {
        FavouritePosts.findOrCreate({
            where: [{
                user_id: user_id
            }, {
                post_id: post_id
            }],
            defaults: {
                user_id: user_id,
                post_id: post_id
            }
        }).then(function(result) {
            res.end(JSON.stringify({
                response: 1,
                message: "Post added to favourite"
            }));
        }, function(error) {
            console.log(error);
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));
    }
}

exports.delete_post_favourite = function(req, res) {
    var user_id = req.body.user_id,
        post_id = req.body.post_id;

    if (user_id != "" && user_id != null && post_id != "" && post_id != null) {
        FavouritePosts.destroy({
            where: [{
                user_id: user_id
            }, {
                post_id: post_id
            }]
        }).then(function(result) {
            if (result == 1) {
                res.end(JSON.stringify({
                    response: 1,
                    message: "Post added to favourite"
                }));
            } else {
                res.end(JSON.stringify({
                    response: 0,
                    message: "can't delete post"
                }));
            }
        }, function(error) {
            console.log(error);
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));
    }
}

exports.my_favourite_post_list = function(req, res) {
    var user_id = req.body.user_id;

    if (user_id != "" && user_id != null) {
        FavouritePosts.findAll({
            where: {
                user_id: user_id
            },
            include: [{
                model: MyPost,
                as: 'mypost_in_favourite_posts',
                include: [{
                    model: PostFiles,
                    as: 'post_attachments_in_post'
                }, {
                    model: User,
                    as: 'user_in_mypost'
                }]
            }]
        }).then(function(result) {
            if (result.length > 0) {
                res.end(JSON.stringify({
                    response: 1,
                    message: "Favourite list found",
                    result: result
                }));
            } else {
                res.end(JSON.stringify({
                    response: 2,
                    message: "Favourite list empty"
                }));
            }
        }, function(error) {
            console.log(error);
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));
    }
}

exports.add_friend_qrcode = function(req, res) {
    var qrcode = req.body.qrcode,
        user_id = req.body.user_id;

    if (qrcode != "" && qrcode != null && user_id != "" && user_id != null) {
        User.findOne({
            where: [{
                unique_user_id: qrcode
            }]
        }).then(function(result) {
            if (result != null) {
                if (result.id == user_id) {
                    res.end(JSON.stringify({
                        response: 2,
                        message: "can't add your own self"
                    }));
                } else {
                    UserContacts.findOne({
                        where: [{
                            $or: [{
                                user_id: user_id,
                                receiver_id: result.id
                            }, {
                                user_id: result.id,
                                receiver_id: user_id
                            }]
                        }]
                    }).then(function(resl) {
                        if (resl == null) {
                            UserContacts.create({
                                user_id: user_id,
                                receiver_id: result.id,
                                status: 'pending'
                            }).then(function(resul) {
                                res.end(JSON.stringify({
                                    response: 1,
                                    message: "Your request sent"
                                }));
                            }, function(errorr) {
                                console.log(errorr);
                                res.end(JSON.stringify({
                                    response: 0,
                                    message: "some error occured"
                                }));
                            })
                        } else {
                            if (resl.status == 'pending') {
                                res.end(JSON.stringify({
                                    response: 3,
                                    message: "You already made a request"
                                }));
                            } else if (resl.status == 'accepted') {
                                res.end(JSON.stringify({
                                    response: 3,
                                    message: "User is already in your friend list"
                                }));
                            }
                        }
                    }, function(err) {
                        console.log(err);
                        res.end(JSON.stringify({
                            response: 0,
                            message: "some error occured"
                        }));
                    })
                    //res.end(JSON.stringify({response:1, message:"User Added"}));
                }
            } else {
                res.end(JSON.stringify({
                    response: 0,
                    message: "User Not found"
                }));
            }
        }, function(error) {
            console.log(error);
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));
    }
}

exports.qrcode_user_detail = function(req, res) {
    var qrcode = req.body.qrcode,
        user_id = req.body.user_id;

    if (qrcode != "" && qrcode != null && user_id != "" && user_id != null) {
        User.findOne({
            where: {
                unique_user_id: qrcode
            }
        }).then(function(result) {
            if (result != null) {
                UserContacts.findOne({
                    where: [{
                        $or: [{
                            user_id: user_id,
                            receiver_id: result.id,
                            status: 'blocked'
                        }, {
                            user_id: result.id,
                            receiver_id: user_id,
                            status: 'blocked'
                        }]
                    }]
                }).then(function(resl) {
                    if (resl != null) {
                        res.end(JSON.stringify({
                            response: 0,
                            message: "User Not found"
                        }));
                    } else {
                        var resp = {};
                        resp.id = result.id;
                        resp.unique_user_id = result.unique_user_id;
                        resp.name = result.name;
                        resp.email = result.email;
                        resp.profile_image = result.profile_image;
                        resp.cover_image = result.profile_image;
                        resp.address = result.address;
                        resp.latitude = result.latitude;
                        resp.longitude = result.longitude;
                        res.end(JSON.stringify({
                            response: 1,
                            message: "User found",
                            result: resp
                        }));
                    }
                }, function(err) {
                    console.log(error);
                    res.end(JSON.stringify({
                        response: 0,
                        message: "some error occured"
                    }));
                })
            } else {
                res.end(JSON.stringify({
                    response: 0,
                    message: "User Not found"
                }));
            }
        }, function(error) {
            console.log(error);
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));
    }
}

exports.qrcode_request_list = function(req, res) {
    var user_id = req.body.user_id;
    if (user_id != "" && user_id != null) {
        UserContacts.findAll({
            where: [{
                receiver_id: user_id
            }, {
                status: 'pending'
            }],
            include: [{
                model: User,
                as: 'sender_user_in_usercontacts',
                attributes: ['id', 'name', 'profile_image']
            }]
        }).then(function(result) {
            if (result.length > 0) {
                res.end(JSON.stringify({
                    response: 1,
                    message: "Requested List Fetched.",
                    result: result
                }));
            } else {
                res.end(JSON.stringify({
                    response: 2,
                    message: "Requested List Empty."
                }));
            }
        }, function(error) {
            console.log(error);
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured."
            }));
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format."
        }));
    }
}

exports.qrcode_accept_reject = function(req, res) {
    var user_id = req.body.user_id,
        request_id = req.body.request_id,
        accept_status = req.body.accept_status;

    if (user_id != "" && user_id != null && request_id != "" && request_id != null && accept_status != "" && accept_status != null) {
        UserContacts.findOne({
            where: [{
                receiver_id: user_id
            }, {
                id: request_id
            }]
        }).then(function(result) {
            if (result != null) {
                if (accept_status == 1) {
                    result.update({
                        status: 'accepted'
                    }).then(function(resl) {
                        res.end(JSON.stringify({
                            response: 1,
                            message: "request accepted."
                        }));
                    }, function(err) {
                        console.log(err);
                        res.end(JSON.stringify({
                            response: 0,
                            message: "some error occured."
                        }));
                    })
                } else if (accept_status == 2) {
                    result.destroy().then(function(resl) {
                        res.end(JSON.stringify({
                            response: 1,
                            message: "request rejected."
                        }));
                    }, function(err) {
                        console.log(err);
                        res.end(JSON.stringify({
                            response: 0,
                            message: "some error occured."
                        }));
                    })
                } else {

                }
            } else {
                res.end(JSON.stringify({
                    response: 0,
                    message: "data not found in database"
                }));
            }
        }, function(error) {
            console.log(error);
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));
    }
}

exports.get_chat_room_id = function(req, res) {
    var user_id = req.body.user_id,
        receiver_id = req.body.receiver_id;

    if (user_id != "" && user_id != null && receiver_id != "" && receiver_id != null) {
        if (user_id == receiver_id) {
            res.end(JSON.stringify({
                response: 2,
                message: "user and receiver id can't be same"
            }));
        }
        ChatRoomIds.findOne({
            where: [{
                $or: [{
                    user_id: user_id,
                    receiver_id: receiver_id
                }, {
                    user_id: receiver_id,
                    receiver_id: user_id
                }]
            }]
        }).then(function(result) {
            if (result == null) {
                var new_room_id = Date.now() + user_id + receiver_id;
                ChatRoomIds.create({
                    room_id: new_room_id,
                    user_id: user_id,
                    receiver_id: receiver_id
                }).then(function(reslt) {
                    res.end(JSON.stringify({
                        response: 1,
                        message: "chat room id found",
                        result: reslt
                    }));
                }, function(err) {
                    console.log(err);
                    res.end(JSON.stringify({
                        response: 0,
                        message: "some error occured"
                    }));
                })
            } else {
                res.end(JSON.stringify({
                    response: 1,
                    message: "chat room id found",
                    result: result
                }));
            }
        }, function(error) {
            console.log(error);
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));
    }
}

exports.save_chat = function(msgdata) {
    console.log('data of chat', msgdata)
    var room_id = msgdata.room_id,
        sender_id = msgdata.sender_id,
        receiver_id = msgdata.receiver_id,
        message = msgdata.message,
        unique_code = msgdata.unique_code;

    if (room_id != null && room_id != '' && message != null && message != '' && sender_id != null && sender_id != '' && receiver_id != null && receiver_id != '') {
        Chats.create({
            room_id: room_id,
            sender_id: sender_id,
            receiver_id: receiver_id,
            message: message,
            unique_code: unique_code
        }).then(function(result) {
            console.log('hello here >>>>>><<<<<<<<<', result.id);
            if (result) {
                ChatRoomIds.update({
                    last_message_id: result.id
                });
            }
        }, function(error) {
            // console.log(error);
            // res.end(JSON.stringify({response:0, message:"some error occured"}));                              
        })
    }
}

exports.get_my_contact_list = function(req, res) {
    var user_id = req.body.user_id;

    if (user_id != "" && user_id != null) {
        UserContacts.findAll({
            where: [{
                $or: [{
                    user_id: user_id
                }, {
                    receiver_id: user_id
                }]
            }, {
                status: 'accepted'
            }],
            include: [{
                model: User,
                attributes: ['id', 'occupant_id', 'name', 'email', 'country_code', 'phone_no', 'profile_image', 'cover_image', 'address', 'latitude', 'longitude'],
                as: 'receiver_user_in_usercontacts',
                required: true
            }, {
                model: User,
                attributes: ['id', 'occupant_id', 'name', 'email', 'country_code', 'phone_no', 'profile_image', 'cover_image', 'address', 'latitude', 'longitude'],
                as: 'sender_user_in_usercontacts',
                required: true
            }],
            required: true
        }).then(function(result) {
            if (result.length > 0) {
                res.end(JSON.stringify({
                    response: 1,
                    message: "people list found",
                    result: result
                }));
            } else {
                res.end(JSON.stringify({
                    response: 2,
                    message: "people list is empty"
                }));
            }
        }, function(error) {
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));
    }
}

exports.block_user = function(req, res) {
    var user_id = req.body.user_id,
        receiver_id = req.body.receiver_id;

    if (user_id != "" && user_id != null && receiver_id != "" && receiver_id != null) {
        UserContacts.findOne({
            where: [{
                $or: [{
                    user_id: user_id,
                    receiver_id: receiver_id
                }, {
                    user_id: receiver_id,
                    receiver_id: user_id
                }]
            }]
        }).then(function(result) {
            if (result != null) {
                var blocked_by = "";
                if (result.user_id == user_id) {
                    blocked_by = 'user';
                } else {
                    blocked_by = 'receiver';
                }
                result.update({
                    status: 'blocked',
                    blocked_by: blocked_by
                }).then(function(resul) {
                    res.end(JSON.stringify({
                        response: 1,
                        message: "user blocked"
                    }));
                }, function(err) {
                    console.log(err);
                    res.end(JSON.stringify({
                        response: 0,
                        message: "some error occured"
                    }));
                })
            } else {
                UserContacts.create({
                    user_id: user_id,
                    receiver_id: receiver_id,
                    blocked_by: 'user',
                    status: 'blocked'
                }).then(function(resul) {
                    res.end(JSON.stringify({
                        response: 1,
                        message: "user blocked"
                    }));
                }, function(err) {
                    console.log(err);
                    res.end(JSON.stringify({
                        response: 0,
                        message: "some error occured"
                    }));
                })
            }
        }, function(error) {
            console.log(error);
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));
    }
}

exports.get_my_chat_list = function(req, res) {
    var user_id = req.body.user_id;
    if (user_id != "" && user_id != null) {
        ChatRoomIds.findAll({
            where: [{
                $or: [{
                    user_id: user_id
                }, {
                    receiver_id: user_id
                }]
            }],
            include: [{
                model: Chats,
                as: 'chat_in_chatrooms',
                attributes: [
                    [sequelize.fn('COUNT', 'chat_in_chatrooms.id'), 'count']
                ],
                required: false
            }, {
                model: Chats,
                as: 'chatroom_in_chats',
                required: true
            }, {
                model: User,
                attributes: ['id', 'name', 'email', 'country_code', 'phone_no', 'profile_image', 'cover_image'],
                as: 'receiver_user_in_chatrooms',
                required: true
            }, {
                model: User,
                attributes: ['id', 'name', 'email', 'country_code', 'phone_no', 'profile_image', 'cover_image'],
                as: 'sender_user_in_chatrooms',
                required: true
            }],
            order: [
                ['id', 'desc']
            ]
        }).then(function(result) {
            // res.json(result);
            // for(i=0;i<result.length;i++){
            //   this.incc=i;
            //   Chats.findOne({where:{
            //                         room_id:result[i].room_id
            //                       },
            //                       order:[['id','desc']]
            //                     }).then(function(resl){
            //                         //res.json(result[this.incc])
            //                         result[this.incc].chat_in_chatroom=resl;
            //                         // res.json(result);
            //                         if(this.incc == result.length-1){
            //                           console.log('<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>',result);
            //                           res.end(JSON.stringify({response:1, message:"Chat List Found", result:result}));  
            //                         }
            //                       },function(err){
            //                         console.log(err);
            //                         res.end(JSON.stringify({response:0, message:"some error occured"}));                                  
            //                       })
            // }
            res.end(JSON.stringify({
                response: 1,
                message: "User Chat List found",
                result: result
            }));
        }, function(error) {
            console.log(error);
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));
    }
}

exports.get_all_friends_posts = function(req, res) {
    var user_id = req.body.user_id;

    if (user_id != "" && user_id != null) {
        UserContacts.findAll({
            where: [{
                $or: [{
                    user_id: user_id
                }, {
                    receiver_id: user_id
                }]
            }, {
                status: 'accepted'
            }]
        }).then(function(result) {
            var ids = [];
            if (result.length > 0) {
                for (i = 0; i < result.length; i++) {
                    if (user_id != result[i].user_id) {
                        ids.push(result[i].user_id);
                    } else if (user_id != result[i].receiver_id) {
                        ids.push(result[i].receiver_id);
                    }
                }
            }
            ids.push(user_id);
            ids = unique(ids);
            console.log('here in get all momentos')
            MyPost.findAll({
                where: [{
                    user_id: ids
                }],
                include: [{
                    model: PostFiles,
                    as: 'post_attachments_in_post',
                    where: [{
                        status: 'active'
                    }],
                    required: false
                }, {
                    model: User,
                    attributes: ['id', 'name', 'country_code', 'phone_no', 'profile_image', 'cover_image', 'address', 'latitude', 'longitude'],
                    as: 'user_in_mypost',
                    where: [{
                        status: 'active'
                    }],
                    required: true
                }, {
                    model: FavouritePosts,
                    as: 'favourite_posts_in_mypost',
                    where: [{
                        user_id: user_id
                    }],
                    required: false
                }],
                order: [
                    ['updated_at', 'desc']
                ],
                required: true
            }).then(function(resl) {
                if (resl.length > 0) {
                    res.end(JSON.stringify({
                        response: 1,
                        message: "Momento List Found",
                        result: resl
                    }));
                } else {
                    res.end(JSON.stringify({
                        response: 2,
                        message: "Momento List Empty"
                    }));
                }
            }, function(err) {
                console.log(err);
                res.end(JSON.stringify({
                    response: 0,
                    message: "some error occured"
                }));
            })
            // }else{
            //   res.end(JSON.stringify({response:2, message:"List is empty"}));                                
            // }
        }, function(error) {
            console.log(error);
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));
    }
}

exports.seen_status_change = function(msgdata) {
    var room_id = msgdata.room_id,
        unique_code = msgdata.unique_code;

    if (room_id != "" && room_id != null && unique_code != "" && unique_code != null) {
        Chats.update({
            check_status: 'read'
        }, {
            where: {
                room_id: room_id,
                unique_code: unique_code
            }
        });
    }
}

exports.get_near_by_users = function(req, res) {
    var user_id = req.body.user_id,
        latitude = req.body.latitude,
        longitude = req.body.longitude;

    if (user_id != "" && user_id != null && latitude != "" && latitude != null && longitude != "" && longitude != null) {
        sequelize.query("SELECT id,unique_user_id,name,email,profile_image,address,latitude,longitude,about_you, ( 6371 * acos( cos( radians(latitude) ) * cos( radians( " + latitude + ") ) * cos( radians( longitude ) - radians(" + longitude + ") ) + sin( radians(latitude) ) * sin(radians(" + latitude + ")) ) ) AS distance FROM users WHERE (select ( 6371 * acos( cos( radians(latitude) ) * cos( radians( " + latitude + ") ) * cos( radians( longitude ) - radians(" + longitude + ") ) + sin( radians(latitude) ) * sin(radians(" + latitude + ")) ) )) <= 20 AND id <> " + user_id, {
            type: Sequelize.QueryTypes.SELECT
        }).then(function(result) {
            //res.json(result);
            if (result.length > 0) {
                res.end(JSON.stringify({
                    response: 1,
                    message: "Users List Fetched",
                    result: result
                }));
            } else {
                res.end(JSON.stringify({
                    response: 2,
                    message: "Users list is empty"
                }));
            }
        }, function(error) {
            console.log(error);
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        });
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));
    }

}

exports.view_post = function(req, res) {
    var user_id = req.body.user_id,
        post_id = req.body.post_id;

    if (user_id != "" && user_id != null && post_id != "" && post_id != null) {
        ViewedPosts.create({
            user_id: user_id,
            post_id: post_id
        }).then(function(result) {
            res.end(JSON.stringify({
                response: 1,
                message: "post viewed"
            }));
        }, function(error) {
            console.log(error);
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));
    }
}

exports.search_all_momentos = function(req, res) {
    var content = req.body.content,
        user_id = req.body.user_id;
    if (content != "" && content != null && user_id != "" && user_id != null) {
        MyPost.findAll({
            where: [{
                $or: [{
                    title: {
                        $like: '%' + content + '%'
                    }
                }, {
                    description: {
                        $like: '%' + content + '%'
                    }
                }, {
                    location: {
                        $like: '%' + content + '%'
                    }
                }]
            }, {
                status: 'active',
                share: 'public'
            }]
        }).then(function(resultss) {
            // res.json(resultss);
            var idss = [];
            if (resultss.length > 0) {
                for (i = 0; i < resultss.length; i++) {
                    idss.push(resultss[i].id);
                }
                idss = unique(idss);
            }
            UserContacts.findAll({
                where: [{
                    $or: [{
                        user_id: user_id
                    }, {
                        receiver_id: user_id
                    }]
                }, {
                    status: 'accepted'
                }]
            }).then(function(result) {
                if (result.length > 0) {
                    var ids = [];
                    for (i = 0; i < result.length; i++) {
                        if (user_id != result[i].user_id) {
                            ids.push(result[i].user_id);
                        } else if (user_id != result[i].receiver_id) {
                            ids.push(result[i].receiver_id);
                        }
                    }
                    ids.push(user_id);
                    ids = unique(ids);
                    console.log('here in get all momentos')
                    MyPost.findAll({
                        where: [{
                            $or: [{
                                user_id: ids,
                                $or: [{
                                    title: {
                                        $like: '%' + content + '%'
                                    }
                                }, {
                                    description: {
                                        $like: '%' + content + '%'
                                    }
                                }, {
                                    location: {
                                        $like: '%' + content + '%'
                                    }
                                }]
                            }, {
                                id: idss
                            }]
                        }, {
                            status: 'active'
                        }],
                        include: [{
                            model: PostFiles,
                            as: 'post_attachments_in_post'
                        }, {
                            model: User,
                            as: 'user_in_mypost'
                        }, {
                            model: FavouritePosts,
                            as: 'favourite_posts_in_mypost',
                            where: [{
                                user_id: user_id
                            }],
                            required: false
                        }],
                        order: [
                            ['updated_at', 'desc']
                        ]
                    }).then(function(resl) {

                        if (resl.length > 0) {
                            res.end(JSON.stringify({
                                response: 1,
                                message: "Momento List Found",
                                result: resl
                            }));
                        } else {
                            res.end(JSON.stringify({
                                response: 2,
                                message: "Momento List Empty"
                            }));
                        }
                    }, function(err) {
                        console.log(err);
                        res.end(JSON.stringify({
                            response: 0,
                            message: "some error occured"
                        }));
                    })
                } else {
                    res.end(JSON.stringify({
                        response: 2,
                        message: "List is empty"
                    }));
                }
            }, function(error) {
                console.log(error);
                res.end(JSON.stringify({
                    response: 0,
                    message: "some error occured"
                }));
            })
        }, function(error) {
            console.log(error);
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));
    }
}

exports.unblock_user = function(req, res) {
    var user_id = req.body.user_id,
        receiver_id = req.body.receiver_id;

    if (user_id != "" && user_id != null && receiver_id != "" && receiver_id != null) {
        UserContacts.findOne({
            where: [{
                $or: [{
                    user_id: user_id,
                    receiver_id: receiver_id,
                    status: 'blocked'
                }, {
                    user_id: receiver_id,
                    receiver_id: user_id,
                    status: 'blocked'
                }]
            }]
        }).then(function(result) {
            if (result != null) {
                if (user_id == result.user_id && result.blocked_by == 'user') {
                    result.destroy();
                    res.send(JSON.stringify({
                        response: 1,
                        message: 'User Unblocked'
                    }));
                } else if (user_id == result.receiver_id && result.blocked_by == 'receiver') {
                    result.destroy();
                    res.send(JSON.stringify({
                        response: 1,
                        message: 'User Unblocked'
                    }));
                } else {
                    res.end(JSON.stringify({
                        response: 0,
                        message: "Can't unblock user"
                    }));
                }
            } else {
                res.end(JSON.stringify({
                    response: 0,
                    message: "Record Not found"
                }));
            }
        }, function(error) {
            console.log(error);
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));
    }
}

exports.blocked_users_list = function(req, res) {
    var user_id = req.body.user_id;
    if (user_id != "" && user_id != null) {
        UserContacts.findAll({
            where: [{
                $or: [{
                    user_id: user_id,
                    status: 'blocked',
                    blocked_by: 'user'
                }, {
                    receiver_id: user_id,
                    status: 'blocked',
                    blocked_by: 'receiver'
                }]
            }],
            include: [{
                model: User,
                attributes: ['id', 'name', 'country_code', 'phone_no', 'profile_image', 'cover_image', 'address', 'latitude', 'longitude'],
                as: 'receiver_user_in_usercontacts',
                required: true
            }, {
                model: User,
                attributes: ['id', 'name', 'country_code', 'phone_no', 'profile_image', 'cover_image', 'address', 'latitude', 'longitude'],
                as: 'sender_user_in_usercontacts',
                required: true
            }]
        }).then(function(result) {
            // res.json(result);
            if (result.length > 0) {
                res.end(JSON.stringify({
                    response: 1,
                    message: "Blocked Users list",
                    result: result
                }));
            } else {
                res.end(JSON.stringify({
                    response: 2,
                    message: "Blocked Users list empty"
                }));
            }
        }, function(error) {
            console.log(error);
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));
    }
}

exports.get_chat_from_room = function(req, res) {
    var room_id = req.body.user_id;

    // sequelize.query("SELECT * FROM chat_room_ids INNER JOIN ( SELECT * FROM chat_room_ids WHERE chat_room_ids.user_id='1' ORDER BY chat_room_ids.id LIMIT 10) X ON (chat_room_ids.room_id=X.room_id) LEFT JOIN chats ON (chat_room_ids.room_id = chats.room_id)"
    // ).then(function(resl){
    //   res.json(resl);
    // },function(err){
    //   console.log(err);
    //   res.json(err);
    // })
}

exports.get_all_chat_stickets = function(req, res) {
    ChatStickersCategories.findAll({
        where: {
            status: 'active'
        },
        include: [{
            model: ChatStickers,
            as: 'chat_stickers_in_category',
        }]
    }).then(function(result) {
        res.end(JSON.stringify({
            response: 1,
            message: "all stickers found",
            result: result
        }));
    }, function(error) {
        console.log(error);
        res.end(JSON.stringify({
            response: 0,
            message: "some error occured"
        }));
    })
}

exports.add_gcm_device = function(req, res) {
    var user_id = req.body.user_id,
        device_id = req.body.device_id,
        device_type = req.body.device_type
        device_token = req.body.device_token,
        occupant_id = req.body.occupant_id,
        ios_voice_token = req.body.ios_voice_token;
    // console.log(req.body);
    if (user_id != "" && device_id != "" && device_token != "") {
        if (device_type == 1) {
            device_type == 'android';
        } else if (device_type == 2) {
            device_type == 'ios';
        } else {
            res.end(JSON.stringify({
                response: 0,
                message: "can't find device type"
            }));
        }
        GcmDevices.findOne({
            where: [{
                user_id: user_id
            }, {
                device_id: device_id
            }]
        }).then(function(result) {
            var update_data = {};

            update_data.user_id = user_id;
            
            if(device_id != "" && device_id != null){
                update_data.device_id = device_id;    
            }

            if(device_type != "" && device_type != null){
                update_data.device_type = device_type;    
            }

            if(device_token != "" && device_token != null){
                update_data.device_token = device_token;    
            }

            if(occupant_id != "" && occupant_id != null){
                update_data.occupant_id = occupant_id;    
            }

            if(ios_voice_token != "" && ios_voice_token != null){
                update_data.ios_voice_token = ios_voice_token;    
            }

            if (result) {
                result.update(update_data).then(function(reslt) {
                    res.end(JSON.stringify({
                        response: 1,
                        message: "device added"
                    }));
                    // console.log(result);
                }, function(err) {
                    res.end(JSON.stringify({
                        response: 0,
                        message: "some problem in adding gcm device"
                    }));
                })
            } else {
                GcmDevices.create(update_data).then(function(reslt) {
                    res.end(JSON.stringify({
                        response: 1,
                        message: "device added"
                    }));
                    // console.log(result);
                }, function(err) {
                    res.end(JSON.stringify({
                        response: 0,
                        message: "some problem in adding gcm device"
                    }));
                })
            }
        }, function(error) {
            res.end(JSON.stringify({
                response: 0,
                message: "some problem in adding gcm device"
            }));
            console.log(error);
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "Sent Ids are empty"
        }));
    }
}

exports.remove_gcm_device = function(req, res) {
    var user_id = req.body.user_id,
        device_id = req.body.device_id;
    if (user_id != null && device_id != null) {
        GcmDevices.destroy({
            where: [{
                user_id: user_id
            }, {
                device_id: device_id
            }]
        }).then(function(result) {
            res.end(JSON.stringify({
                response: 1,
                message: "device removed"
            }));
        }, function(error) {
            res.end(JSON.stringify({
                response: 0,
                message: "some problem while removing device"
            }));
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "ids are null"
        }));
    }
}

exports.delete_message_notification = function(req, res) {
    var email = req.body.email,
        user_name = req.body.user_name,
        occupant_id = req.body.occupant_id;
    if (occupant_id != "" && occupant_id != null && user_name != "" && user_name != null) {
        GcmDevices.findAll({
            where: {
                occupant_id: occupant_id
            }
        }).then(function(resull) {
            if (resull.length > 0) {
                for (incc = 0; incc < resull.length; incc++) {
                    if (resull[incc].device_token != "" && resull[incc].device_token != null) {
                        if (resull[incc].device_type == 'android') {
                            sendNotificationAndroid(resull[incc].device_token, user_name, 'deleted a message', 'delete_message', "", '', function(data) {})
                        } else if (resull[incc].device_type == 'ios') {
                            sendNotificationIos(resull[incc].device_token, user_name, 'deleted a message', "delete_message","", '', function(data) {})
                        }
                    }
                }
            }
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));
    }
}

exports.video_audio_call_notify = function(req, res) {
    var user_id = req.body.user_id,
        caller_id = req.body.caller_id,
        login = req.body.login,
        notification_type = req.body.notification_type,
        user_name = req.body.user_name,
        caller_name = req.body.caller_name,
        email = req.body.email;
    if (user_id != "" && user_id != null && caller_id != "" && caller_id != null && login != "" && login != null && user_name != "" && user_name != null && caller_name != "" && caller_name != null && notification_type != "" && notification_type != null) {
        GcmDevices.findAll({
            where: {
                occupant_id: caller_id
            }
        }).then(function(resull) {
            if (resull.length > 0) {
                for (incc = 0; incc < resull.length; incc++) {
                    if (resull[incc].device_token != "" && resull[incc].device_token != null) {
                        if (resull[incc].device_type == 'android') {
                            sendNotificationAndroid(resull[incc].device_token, 'Red', 'new message', notification_type, "", req.body, function(data) {})
                        } else if (resull[incc].device_type == 'ios') {
                            sendNotificationIosVoice(resull[incc].ios_voice_token, 'Red', 'new message', notification_type, "", req.body, function(data) {})
                        }
                    }
                    if (incc == resull.length - 1) {
                        res.end(JSON.stringify({
                            response: 1,
                            message: "Notification sent successfully",
                            result: req.body
                        }));
                    }
                }
            }
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));
    }
}

//////////////////Favourite content from chat by mohit

var imagepath = local_images_url + 'chat_attachments/';
exports.Favcontentfromchat = function(req, res) {
    console.log(req.body);
    var finalattachmentname;
    var finalattachmenttype;
    var value = {}
    value.user_id = req.body.user_id;
    value.unique_check = req.body.unique_check;
    value.occupant_id = req.body.occupant_id;
    if ((req.body.unique_check && req.files && req.files.attachment && req.body.occupant_id) || (req.body.unique_check && req.body.text && req.body.occupant_id)) {
        favcontentfromchat.findOne({
            where: [{
                    unique_check: req.body.unique_check
                }, {
                    user_id: req.body.user_id
                }
            ]
        }).then(data => {
            if (data) {
                res.send({
                    response: 1,
                    message: 'You are already added in favourite list'
                })
            } else {
                if (req.files) {
                    var attachment1 = req.files.attachment;
                    var attachment_name = attachment1.name;
                    attachment1.mv(imagepath + attachment_name, function(err) {
                        if (err) {
                            res.send({
                                response: 0,
                                message: "File not uploaded"
                            });
                        }
                    })
                    if (req.body.attachment_type == 'video') {
                        var thumbnails = req.files.thumbnail;
                        var thumbnail_name = thumbnails.name;
                        value.thumbnail = thumbnail_name;
                        thumbnails.mv(imagepath + thumbnail_name, function(err) {
                            if (err) {
                                res.send({
                                    response: 0,
                                    message: "File not uploaded"
                                });
                            }
                        })
                    }

                    if (req.body.attachment_type == 'map') {
                        if (req.body.lat == null || req.body.lat == '' ||
                            req.body.long == null || req.body.long == '' ||
                            req.body.address == null || req.body.address == '') {
                            res.end({
                                response: 0,
                                message: 'Please fill the missing details like lattitude,longitude and address'
                            })
                        } else {
                            value.attachment = attachment_name;
                            value.attachment_type = req.body.attachment_type;
                            value.lat = req.body.lat;
                            value.long = req.body.long;
                            value.address = req.body.address;
                        }
                    } else {
                        value.attachment = attachment_name;
                        value.attachment_type = req.body.attachment_type;

                    }

                } else {

                    value.text = req.body.text

                }

                favcontentfromchat.create(value).then(newdata => {
                    res.send({
                        response: 1,
                        data: newdata,
                        message: 'successfully added in your favourite list.'
                    })


                }, err => {
                    console.log(err);
                    res.send({
                        response: 0,
                        message: "some error occured"
                    })

                })
            }

        }, error => {
            console.log(error)
            res.send({
                response: 0,
                message: "some error occured"
            })
        })
    } else {
        res.send({
            response: 0,
            message: "Please send unique_check , email, text or attachment "
        })
    }

}

//////////////////Favourite content list from chat by mohit
// favcontentfromchat.belongsTo(User,{
//   foreignKey:'email',
//   sourceKey:'email',
//   as:'ChatUsersDetails'
// })

exports.Favcontentlistfromchat = function(req, res) {
    favcontentfromchat.findAll({
        where: {
            user_id: req.params.user_id
        },
        include: [{
            model: User,
            as: 'ChatUsersDetails'
        }]


    }).then(data => {

        res.send({
            response: 1,
            message: "Success",
            data: data
        })

    }, error => {
        console.log(error)
        res.send({
            response: 0,
            message: "some error occured",
            result: error
        })
    })

}

exports.Favcontentdeletefromchat = function(req, res) {
    favcontentfromchat.destroy({
        where: {
            id: req.params.id
        }


    }).then(data => {
        if (data) {
            res.send({
                response: 1,
                data: data,
                message: 'Data deleted'
            })
        } else {
            res.send({
                response: 1,
                message: 'Data not found with entered id'
            })
        }

    }, error => {
        res.send({
            response: 0,
            message: "some error occured"
        })
    })

}

/////////////////Favourite content delete from chat by mohit End

//////////Subodh kumar @ 20-march quickblox
exports.quickblox_set_status = function(req, res) {
    var user_id = req.body.user_id,
        occupant_id = req.body.occupant_id,
        hide_status = req.body.hide_status;

    if (user_id != "" && user_id != null && hide_status != "" && hide_status != null && occupant_id != "" && occupant_id != null) {
        QuickbloxChatUsers.findOne({
            where: [{
                user_id: user_id,
                occupant_id: occupant_id
            }]
        }).then(function(result) {
            console.log(req.body);
            if (hide_status != '0' && hide_status != '1') {
                res.end(JSON.stringify({
                    response: 0,
                    message: "wrong status sent"
                }));
            }

            if (result != null) {
                result.update({
                    hide_status: hide_status
                }).then(function(resl) {
                    res.end(JSON.stringify({
                        response: 1,
                        message: "status updated"
                    }));
                }, function(err) {
                    console.log(err);
                    res.end(JSON.stringify({
                        response: 0,
                        message: "some error occured"
                    }));
                })
            } else {
                User.findOne({
                    where: {
                        occupant_id: occupant_id
                    }
                }).then(function(reslt) {
                    var receiver_user_id = "";
                    if (reslt) {
                        receiver_user_id = reslt.id;
                    }
                    QuickbloxChatUsers.create({
                        user_id: user_id,
                        receiver_user_id: receiver_user_id,
                        hide_status: hide_status,
                        occupant_id: occupant_id
                    }).then(function(resultt) {
                        res.end(JSON.stringify({
                            response: 1,
                            message: "status updated"
                        }));
                    }, function(errorrr) {
                        console.log(errorrr);
                        res.end(JSON.stringify({
                            response: 0,
                            message: "some error occured"
                        }));
                    })
                }, function(errr) {
                    console.log(errr);
                    res.end(JSON.stringify({
                        response: 0,
                        message: "some error occured"
                    }));
                })
            }
        }, function(error) {
            console.log(error);
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));
    }
}

/*get all data based on user_id from quickblox_chat_users*/
exports.get_quickblox_chat_users = function(req, res) {
    var user_id = req.body.user_id;
    if (user_id != "" && user_id != null) {
        QuickbloxChatUsers.findAll({
            where: [{
                user_id: user_id,
                hide_status: '1'
            }],
            include: [{
                model: User,
                as: 'receiver_user_in_quickblox',
                attributes: ['name', 'country_code', 'phone_no', 'occupant_id']
            }]
        }).then(function(result) {
            if (result.length > 0) {
                res.end(JSON.stringify({
                    response: 1,
                    message: "List Fetched",
                    result: result
                }));
            } else {
                res.end(JSON.stringify({
                    response: 2,
                    message: "List is empty"
                }));
            }
        }, function(error) {
            console.log(error);
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));
    }
}
//////////Subodh kumar @ 20-march quickblox end

//////////Subodh kumar @ 20-march add passcode for user app
exports.user_add_passcode = function(req, res) {
    var user_id = req.body.user_id,
        passcode = req.body.passcode; /*passcode is latest passcode user want to add for his/her account*/

    if (user_id != "" && user_id != null && passcode != "" && passcode != null) {
        UsersAppPasscode.findOne({
            where: {
                user_id: user_id
            }
        }).then(function(result) {
            if (result != null) {
                /*if user wants to update passcode @20-march-2018*/
                if (req.body.old_passcode) { /*old_passcode field is to get the old passcode of user*/
                    result.update({
                        passcode: passcode
                    }).then(function(reslt) {
                        res.end(JSON.stringify({
                            response: 1,
                            message: "Passcode updated successfully."
                        }));
                    }, function(err) {
                        console.log(err);
                        res.end(JSON.stringify({
                            response: 0,
                            message: "some error occured"
                        }));
                    })
                } else {
                    res.end(JSON.stringify({
                        response: 0,
                        message: "Passcode is already generated."
                    }));
                }
                /*if user wants to update passcode end*/
            } else {
                /*add new user's passcode first time in table @20-march-2018*/
                UsersAppPasscode.create({
                    user_id: user_id,
                    passcode: passcode
                }).then(function(reslt) {
                    res.end(JSON.stringify({
                        response: 1,
                        message: "Passcode added successfully."
                    }));
                }, function(err) {
                    console.log(err);
                    res.end(JSON.stringify({
                        response: 0,
                        message: "some error occured"
                    }));
                })
                /*add new user's passcode first time in table @20-march-2018 end*/
            }
        }, function(error) {
            console.log(error);
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "Wrong data or format."
        }));
    }
}

//////////Subodh kumar @ 20-march add passcode for user app end

//////////Subodh kumar @ 20-march match passcode for user app

exports.user_match_passcode = function(req, res) {
    var user_id = req.body.user_id,
        passcode = req.body.passcode;

    if (user_id != "" && user_id != null && passcode != "" && passcode != null) {
        UsersAppPasscode.findOne({
            where: [{
                user_id: user_id
            }, {
                passcode: passcode
            }]
        }).then(function(result) {
            if (result != null) {
                res.end(JSON.stringify({
                    response: 1,
                    message: "Passcode detected successfully."
                }));
            } else {
                res.end(JSON.stringify({
                    response: 0,
                    message: "Passcode not matched."
                }));
            }
        }, function(error) {
            console.log(error);
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));
    }
}

exports.user_check_passcode_generated = function(req, res) {
    var user_id = req.body.user_id;

    if (user_id != "" && user_id != null) {
        UsersAppPasscode.findOne({
            where: {
                user_id: user_id
            }
        }).then(function(result) {
            if (result != null) {
                res.end(JSON.stringify({
                    response: 1,
                    message: "User already have passcode."
                }));
            } else {
                res.end(JSON.stringify({
                    response: 0,
                    message: "User not have any passcode."
                }));
            }
        }, function(error) {
            console.log(error);
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));
    }
}

//////////Subodh kumar @ 20-march match passcode for user app end

//////////Subodh kumar @ 21-march forgot passcode for user app
exports.user_forgot_passcode = function(req, res) {
    var user_id = req.body.user_id;

    if (user_id != "" && user_id != null) {
        UsersAppPasscode.findOne({
            where: [{
                user_id: user_id
            }]
        }).then(function(result) {
            if (result != null) {
                User.findOne({
                    where: {
                        id: user_id
                    }
                }).then(function(resl) {
                    if (resl != null) {
                        //res.json(resl)
                        var new_passcode = Math.floor(1000 + Math.random() * 9000);
                        result.update({
                            passcode: new_passcode
                        });
                        var mailOptions = {
                            to: resl.email,
                            subject: 'Red (New Passcode)',
                            user: {
                                passcode: new_passcode,
                                path: global_images_url
                            }
                        }
                        send_email('red_new_passcode', mailOptions, function() {
                            res.end(JSON.stringify({
                                response: 1,
                                message: "We have sent you an email."
                            }));
                        });
                    } else {
                        res.end(JSON.stringify({
                            response: 1,
                            message: "User not found."
                        }));
                    }
                }, function(err) {
                    res.end(JSON.stringify({
                        response: 1,
                        message: "some error occured"
                    }));
                })
                //res.end(JSON.stringify({response:1, message:"passcode detected successfully"}));
            } else {
                res.end(JSON.stringify({
                    response: 0,
                    message: "Passcode not generated yet."
                }));
            }
        }, function(error) {
            console.log(error);
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));
    }
}
//////////Subodh kumar @ 21-march forgot passcode for user app end

//////////Subodh kumar @ 23-march volte content get for chat users quickblox
exports.volte_content_from_chat = function(req, res) {
    var finalattachmentname,
        finalattachmenttype;
    var value = {};

    value.user_id = req.body.user_id;
    value.unique_check = req.body.unique_check;
    value.occupant_id = req.body.occupant_id;
    if ((req.body.unique_check && req.files && req.files.attachment && req.body.occupant_id) || (req.body.unique_check && req.body.text && req.body.occupant_id)) {
        VolteContentFromChat.findOne({
            where: [{
                unique_check: req.body.unique_check
            }, {
                user_id: req.body.user_id
            }]
        }).then(data => {
            if (data) {
                res.end(JSON.stringify({
                    response: 1,
                    message: 'You are already added in volte list'
                }))
            } else {
                if (req.files) {
                    var attachment1 = req.files.attachment;
                    var attachment_name = attachment1.name;
                    attachment1.mv(imagepath + attachment_name, function(err) {
                        if (err) {
                            res.end(JSON.stringify({
                                response: 0,
                                message: "File not uploaded"
                            }));
                        }
                    })
                    if (req.body.attachment_type == 'video') {
                        var thumbnails = req.files.thumbnail;
                        var thumbnail_name = thumbnails.name;
                        value.thumbnail = thumbnail_name;
                        thumbnails.mv(imagepath + thumbnail_name, function(err) {
                            if (err) {
                                res.end(JSON.stringify({
                                    response: 0,
                                    message: "File not uploaded"
                                }));
                            }
                        })
                    }

                    if (req.body.attachment_type == 'map') {
                        if (req.body.lat == null || req.body.lat == '' || req.body.long == null || req.body.long == '' || req.body.address == null || req.body.address == '') {
                            res.end(JSON.stringify({
                                response: 0,
                                message: 'Please fill the missing details like lattitude,longitude and address'
                            }))
                        } else {
                            value.attachment = attachment_name;
                            value.attachment_type = req.body.attachment_type;
                            value.lat = req.body.lat;
                            value.long = req.body.long;
                            value.address = req.body.address;
                        }
                    } else {
                        value.attachment = attachment_name;
                        value.attachment_type = req.body.attachment_type;
                    }
                } else {
                    value.text = req.body.text
                }

                VolteContentFromChat.create(value).then(newdata => {
                    res.end(JSON.stringify({
                        response: 1,
                        message: 'successfully added in your volte list.',
                        result: newdata
                    }))
                }, err => {
                    console.log(err);
                    res.end(JSON.stringify({
                        response: 0,
                        message: "some error occured"
                    }));
                })
            }

        }, error => {
            console.log(error);
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "Please send unique_check , email, text or attachment "
        }))
    }
}
//////////Subodh kumar @ 23-march volte content get for chat users quickblox end

//////////Subodh kumar @ 24-march volte content list from table
exports.volte_content_list_from_chat = function(req, res) {
    VolteContentFromChat.findAll({
        where: {
            user_id: req.params.user_id
        },
        include: [{
            model: User,
            as: 'VolteChatUsersDetails'
        }]
    }).then(data => {
        res.end(JSON.stringify({
            response: 1,
            message: "Success",
            result: data
        }));
    }, error => {
        console.log(error)
        res.end(JSON.stringify({
            response: 0,
            message: "some error occured",
            result: error
        }))
    })
}
//////////Subodh kumar @ 24-march volte content list from table end

/////////////////Volte content delete from chat by Subodh kumar @ 23-march
exports.volte_content_delete_from_chat = function(req, res) {
    VolteContentFromChat.destroy({
        where: {
            id: req.params.id
        }
    }).then(data => {
        if (data) {
            res.send({
                response: 1,
                message: 'Data deleted',
                result: data
            })
        } else {
            res.send({
                response: 1,
                message: 'Data not found with entered id'
            })
        }
    }, error => {
        res.send({
            response: 0,
            message: "some error occured"
        })
    })
}
/////////////////Volte content delete from chat by Subodh kumar @ 23-march end

//////////Subodh kumar @ 03-april quickblox set staus for all of same user
exports.quickblox_set_status_all_users = function(req, res) {
    var user_id = req.body.user_id,
        hide_status = req.body.hide_status;

    if (user_id != "" && user_id != null && hide_status != "" && hide_status != null) {
        if (hide_status != '0' && hide_status != '1') {
            res.end(JSON.stringify({
                response: 0,
                message: "wrong status sent"
            }));
        }

        QuickbloxChatUsers.update({
            hide_status: hide_status
        }, {
            where: {
                user_id: user_id
            }
        }).then(function(resl) {
            res.end(JSON.stringify({
                response: 1,
                message: "status updated"
            }));
        }, function(err) {
            console.log(err);
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));
    }
}
//////////Subodh kumar @ 03-april quickblox set status for all end

// General message push notification send @03-april subodh kumar
exports.general_message_notification = function(req, res) {
    var user_email = req.body.user_email,
        user_name = req.body.user_name,
        message = req.body.message,
        occupant_id = req.body.occupant_id;
    if (occupant_id != "" && occupant_id != null && user_name != "" && user_name != null && message != "" && message != null) {
        //console.log(req.body);
        GcmDevices.findAll({
            where: {
                occupant_id: occupant_id
            },include:[{
                model:UserSettings,
                as:'user_settings_in_gcm_devices'
            }]
        }).then(function(resull) {
            //console.log(resull);
            if (resull.length > 0) {
                //console.log('1');
                for (incc = 0; incc < resull.length; incc++) {
                    if (resull[incc].device_token != "" && resull[incc].device_token != null) {
                        if(resull[incc].user_settings_in_gcm_devices.send_message_notification && resull[incc].user_settings_in_gcm_devices.send_message_notification == 'yes'){
                            if (resull[incc].device_type == 'android') {
                                sendNotificationAndroid(resull[incc].device_token, user_name, message, 'general_message_notification', "", req.body, function(data) {})
                            } else if (resull[incc].device_type == 'ios') {
                                sendNotificationIos(resull[incc].device_token, user_name, message, 'general_message_notification', '', req.body, function(data) {})
                            }
                        }
                    }
                }
            }
        })
    } else {
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));
    }
}
// General message push notification send @03-april end subodh kumar 

exports.test_noti_with_occupant=function(req,res){
    var occupant_id=req.body.occupant_id;

    if(occupant_id != "" && occupant_id != null){
        GcmDevices.findAll({
            where: {
                occupant_id: occupant_id
            }
        }).then(function(resull) {
            console.log(resull);
            if (resull.length > 0) {
                //console.log('1');
                for (incc = 0; incc < resull.length; incc++) {
                    if (resull[incc].device_token != "" && resull[incc].device_token != null) {
                        if (resull[incc].device_type == 'android') {
                            sendNotificationAndroid(resull[incc].device_token, 'user_name', 'message', 'general_message_notification', "", req.body, function(data) {})
                        } else if (resull[incc].device_type == 'ios') {
                            sendNotificationIos(resull[incc].device_token, 'user_name', 'message', 'general_message_notification', '', req.body, function(data) {})
                        }
                    }
                }
            }
        })
    }else{
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));    
    }
}

exports.change_user_settings=function(req, res){
    var user_id = req.body.user_id,
        send_message_notification = req.body.send_message_notification;

    if(user_id != "" && user_id != null){
        var update_data = {};
        if(send_message_notification != "" && send_message_notification != null){
            if(send_message_notification == 'yes' || send_message_notification == 'no'){
                update_data.send_message_notification = send_message_notification
            }else{
                res.end(JSON.stringify({
                    response: 0,
                    message: "wrong data or format"
                }));           
            }
        }

        UserSettings.findOne({
            where:{
                user_id:user_id
            }
        }).then(function(settings){
            if(settings != null){
                settings.update(update_data).then(function(result){
                    res.end(JSON.stringify({
                        response: 1,
                        message: "Data updated successfully"
                    }));       
                },function(error){
                    res.end(JSON.stringify({
                        response: 0,
                        message: "some error occured"
                    }));        
                })
            }else{
                update_data.user_id = user_id;
                
                UserSettings.create(update_data).then(function(){
                    res.end(JSON.stringify({
                        response: 1,
                        message: "Data added successfully"
                    }));
                },function(error){
                    console.log('error',error);
                    res.end(JSON.stringify({
                        response: 0,
                        message: "some error occured"
                    }));
                })
            }
        },function(setting_error){
            console.log('setting_error',setting_error);
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));
        })
    }else{
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));   
    }
}

exports.get_user_settings=function(req, res){
    var user_id = req.body.user_id;

    if(user_id != "" && user_id != null){
        UserSettings.findOne({
            where:{
                user_id:user_id
            }
        }).then(function(result){
            res.end(JSON.stringify({
                response: 1,
                message: "data fetched",
                result:result
            }));
        },function(error){
            res.end(JSON.stringify({
                response: 0,
                message: "some error occured"
            }));    
        })
    }else{
        res.end(JSON.stringify({
            response: 0,
            message: "wrong data or format"
        }));   
    }
}

////////////////////Get Calculated Distance////////////
function getDistanceFromLatLonInKm(lat1, lon1, lat2, lon2, callback) {
    var R = 6371; // Radius of the earth in km
    var dLat = deg2rad(lat2 - lat1); // deg2rad below
    var dLon = deg2rad(lon2 - lon1);
    var a =
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
        Math.sin(dLon / 2) * Math.sin(dLon / 2);
    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    var d = R * c; // Distance in km
    callback(d);
}

function deg2rad(deg) {
    return deg * (Math.PI / 180)
}
//////////////////Get Calculated Distance End//////////

////////////////////////////////////////////////////////
///////////////// Red Mart Section /////////////////////

// exports.dummy=function(res){
//   //res.send('<h3> Server is connected on port no : 3002');
//   res('done from here');
// }

///////////////// Red Mart Section End /////////////////
////////////////////////////////////////////////////////
function send_email(template, mailOptions, callback) {
    // Send email.
    app.mailer.send(template, mailOptions, function(err, message) {
        if (err) {
            console.log(err);
            //res.send('There was an error sending the email');
            return;
        }
        callback();
        //return res.send('Email has been sent!');
    });
}

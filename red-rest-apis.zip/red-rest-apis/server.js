var express=require('express');
var app=express();
var routes=require('./routes/index.js');
var bodyParser=require('body-parser');
var fileUpload = require('express-fileupload');

app.use(bodyParser.json({limit: '1000mb'}));

app.use(bodyParser.urlencoded({limit: '1000mb', extended: true }));

app.use(fileUpload());

app.set('views','/var/www/html/red-rest-apis/views');

app.set('view engine', 'ejs');

app.use(express.static(__dirname + '/public'));

app.get('/',routes.home);

app.post('/signUp',routes.sign_up);

app.post('/login',routes.login);

app.post('/changePassword',routes.change_password);

app.post('/forgotPassword',routes.forgot_password);

app.get('/resetPassword/:user_id/:token',routes.reset_password);

app.post('/submitResetPassword',routes.submit_reset_password);

app.post('/submitResetPasswordFromApp',routes.submit_reset_password_from_app);

app.post('/userEditProfile',routes.user_edit_profile);

app.post('/userContactListCreate',routes.user_contact_list_create);

app.post('/userAddPost',routes.user_add_post);

app.post('/getMyPosts',routes.get_my_posts);

app.post('/deletePostAttachment',routes.delete_post_attachment);

app.post('/editMyPost',routes.edit_my_post);

app.post('/deleteMyPost',routes.delete_my_post);

app.post('/addPostFavourite',routes.add_post_favourite);

app.post('/myFavouritePostList',routes.my_favourite_post_list);

app.post('/deletePostFavourite',routes.delete_post_favourite);

app.post('/addFriendQrcode',routes.add_friend_qrcode);

app.post('/qrcodeUserDetail',routes.qrcode_user_detail);

app.post('/getChatRoomId',routes.get_chat_room_id);

app.post('/getMyContactList',routes.get_my_contact_list);

app.post('/getMyChatList',routes.get_my_chat_list);

app.post('/qrcodeRequestList',routes.qrcode_request_list);

app.post('/qrcodeAcceptReject',routes.qrcode_accept_reject);

app.post('/getAllFriendsPosts',routes.get_all_friends_posts);

app.post('/seen_change',routes.seen_status_change);

app.post('/getNearByUsers',routes.get_near_by_users);

app.post('/viewPost',routes.view_post);

app.post('/blockUser',routes.block_user);

app.post('/searchAllMomentos',routes.search_all_momentos);

app.post('/unblockUser',routes.unblock_user);

app.post('/blockedUsersList',routes.blocked_users_list);

app.post('/getChatFromRoom',routes.get_chat_from_room);

app.get('/getAllChatStickets',routes.get_all_chat_stickets);

app.post('/addGcmDevice',routes.add_gcm_device);

app.post('/removeGcmDevice',routes.remove_gcm_device);

app.post('/deleteMessageNotification',routes.delete_message_notification);

app.post('/videoAudioCallNotify',routes.video_audio_call_notify);

app.post('/favcontentfromchat',routes.Favcontentfromchat);//mohit

app.get('/favcontentlistfromchat/:user_id',routes.Favcontentlistfromchat);//mohit

app.get('/favcontentdeletefromchat/:id',routes.Favcontentdeletefromchat);//mohit

app.post('/quickbloxSetStatus',routes.quickblox_set_status);

app.post('/getQuickbloxChatUsers',routes.get_quickblox_chat_users);

app.post('/userAddPasscode',routes.user_add_passcode);

app.post('/userMatchPasscode',routes.user_match_passcode);

app.post('/userForgotPasscode',routes.user_forgot_passcode);

app.post('/userCheckPasscodeGenerated',routes.user_check_passcode_generated);

app.post('/volteContentFromChat',routes.volte_content_from_chat);

app.get('/volteContentListFromChat/:user_id',routes.volte_content_list_from_chat);

app.get('/volteContentDeleteFromChat/:id',routes.volte_content_delete_from_chat);

app.post('/quickbloxSetStatusAllUsers',routes.quickblox_set_status_all_users);

app.post('/generalMessageNotification',routes.general_message_notification);

app.post('/testNotiWithOccupant',routes.test_noti_with_occupant);

app.post('/changeUserSettings',routes.change_user_settings);

app.post('/getUserSettings',routes.get_user_settings);

server=app.listen(3002,function(){
	var port=server.address().port;
	console.log('Running on port no. '+port);
})
